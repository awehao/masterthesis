# 前言圖文稿：Overleaf 上傳包

1. 上傳此 ZIP 建立 Overleaf 專案。
2. Compiler 選 XeLaTeX，Main document 選 main.tex。
3. Recompile，必要時 Recompile from scratch。

main.tex 載入 background_preview.tex，使用 Tsai 的 nthuthesis 類別及原專案字型，輸出第一章前言與參考文獻。01_background.tex 為單一前言節，可嵌入既有第一章。background_references.bib 提供本節六筆引用；合併論文時整合至全論文書目。

figsrc/ch01/ 內含兩張直接取自 IFR 官方的 JPEG 原圖；來源及統計範圍見 SOURCES.md。預設保留原始圖片及來源文字。本包通過引用鍵、交叉引用、圖檔格式、路徑及壓縮完整性檢查，尚未於本機或 Overleaf 完成編譯。

本版書目採標準 IEEEtran，依引用順序產生 [1]–[6]。IEEEtran.bst 隨包提供；網頁附存取日期，期刊採文章編號與 DOI。尚未於本機編譯新樣式。

插圖與交叉引用沿用參考範例的 figure／caption／label／cref 寫法，cleveref 中文圖名已設定。
