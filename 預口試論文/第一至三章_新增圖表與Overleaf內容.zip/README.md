# Overleaf 現行檔案與編輯方式

更新：2026-11-24。格式沿用使用者提供的 `Tsai_thesis.zip`，Compiler 選 XeLaTeX。`main.tex` 載入 `thesis.tex`，目前預設仍只編譯摘要。

| 檔案 | 用途 |
|---|---|
| `abstract_zh.tex`、`abstract_en.tex` | 現行中英文摘要，含住宅整合任務 |
| `nthuvars.tex`、`nthuthesis.cls`、`preamble.tex` | 封面變數、學姐範本及字型／排版設定 |
| `第一章_前言與動機_含圖.tex`、`第一章_本文架構.tex` | 第一章 1.1–1.2、1.4；1.3.5 比較表另見 01_03_05_research_comparison.tex |
| `02_platform_and_interfaces.tex` | 2.1–2.2；平台規格、座標配置與命令鏈 |
| `02_software_and_integration.tex` | 2.3–2.4；含 Smac 2D、AMCL + EKF、Mask R-CNN 資料與示例 |
| `02_workflow_and_recording.tex` | 2.6–2.7；住宅任務與記錄方式 |
| `03_01_kinematics.tex` 至 `03_07_execution_compensation.tex` | 第三章唯一分節來源 |
| `第三章_3.1至3.4完整稿.tex`、`第三章_3.4至3.7完整稿.tex` | 自動整併，供複製；兩者包含重疊的 3.4，不可整份同時載入 |
| `chapters_outline.tex` | 標題骨架；不要與完整正文同時載入 |
| `thesis_references.bib` | 全論文唯一書目主檔 |
| `第三章_示意圖插入.tex` | 16 張原創方法圖的片段；正文已含圖，不重複貼入 |
| `第一至三章_新增內容與插圖位置.md` | 本次八張新增圖、四份表格與演算法框的使用位置及證據 |
| `algorithm_preamble.tex` | 演算法框導言設定；本地 preamble 已載入 |

在學姐專案上修改時，上傳所需分節及 `figsrc` 圖片，再替換對應內容。書目統一使用：

```latex
\bibliographystyle{IEEEtran}
\bibliography{thesis_references}
```

若原 `thesis.bib` 有學姐專案其他章節仍需要的條目，先將獨有條目併入主檔，再切換；不要重複定義相同引用鍵。引用顯示問號時，確認 `\cite{key}` 與主檔鍵名一致，再於 Overleaf 使用 Recompile from scratch。

修改第三章分節後執行 `python3 預口試論文/overleaf/build_manuscript_materials.py`，更新合併稿及目錄。3.5.4 已依第 101 趟圓柱階段紀錄改為關節空間展開；該趟整體任務未完成。

2.1、2.2 與 1.3.5 已補入；2.5 完整 LaTeX 及第一章 1.3.1–1.3.4 未在本資料夾收錄。本資料夾尚不是完整五章的可直接編譯論文。第三章圖面為原創方法圖，PDF 已嵌入標楷體，與實驗結果截圖分別使用。

本次檢查範圍與證據見 [20261124_內容修訂說明.md](20261124_內容修訂說明.md)。舊分章書目及舊 Markdown 已留存上層歷史版本。本機無 XeLaTeX/BibTeX，本次未產生新版摘要或整份論文 PDF。

另補四張英文參考方法圖：Nav2（2.4.1）、旋轉表示（3.1.1）、卡爾曼濾波（3.4.1）、Mask R-CNN（3.5.1）。[插入片段](英文參考圖_插入格式.tex)及[來源清單](figsrc/reference_figures/SOURCES.md)均已整理；分節稿已含圖，不重複貼入。

本次新增圖表及重製來源見 [第一至三章_新增內容與插圖位置.md](第一至三章_新增內容與插圖位置.md)。第三章現在共 22 張圖（原創方法圖 19 張、英文參考圖 3 張）；舊的「16 張」插圖包只包含原先 16 張，不包含本次新增三張。新包為上層 `第一至三章_新增圖表與Overleaf內容.zip`。遮罩例圖執行既有權重的離線推論，未啟動模擬或訓練。
