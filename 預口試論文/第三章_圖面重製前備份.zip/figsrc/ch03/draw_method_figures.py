#!/usr/bin/env python3
"""Original vector schematics for chapter 3. No simulation/results are used."""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "thesis_ch03_mpl"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Arc, Circle, FancyArrowPatch, Polygon, Rectangle
import numpy as np

OUT = Path(__file__).resolve().parent
FONT_PATH = OUT.parents[1] / "fonts" / "kaiu.ttf"
if not FONT_PATH.is_file():
    raise FileNotFoundError("The thesis DFKai-SB font fonts/kaiu.ttf is required.")
FONT = FontProperties(fname=str(FONT_PATH))
plt.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "path",
    "mathtext.fontset": "stix", "axes.unicode_minus": False,
    "savefig.facecolor": "white", "font.size": 10,
})
FONT.set_math_fontfamily("stix")
INK, GRAY, LIGHT = "#111111", "#666666", "#eeeeee"
MANIFEST = []


def txt(ax, x, y, s, size=10, **kw):
    opts = dict(ha="center", va="center", fontproperties=FONT,
                fontsize=size, color=INK, zorder=12, linespacing=1.4)
    opts.update(kw)
    return ax.text(x, y, s, **opts)


def arrow(ax, a, b, lw=1, color=INK, ls="-", rad=0, scale=10):
    ar = FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=scale,
                         linewidth=lw, color=color, linestyle=ls,
                         connectionstyle=f"arc3,rad={rad}",
                         shrinkA=0, shrinkB=0, zorder=5)
    ax.add_patch(ar)
    return ar


def line(ax, points, **kw):
    p = np.asarray(points)
    defaults = dict(color=INK, lw=1, zorder=3)
    defaults.update(kw)
    ax.plot(p[:, 0], p[:, 1], **defaults)


def polyarrow(ax, points, **kw):
    if len(points) > 2:
        line(ax, points[:-1], **kw)
    arrow(ax, points[-2], points[-1], **kw)


def panel(ax, title, xlim, ylim, equal=True):
    ax.set(xlim=xlim, ylim=ylim)
    ax.set_axis_off()
    if equal:
        ax.set_aspect("equal")
    txt(ax, 0.5, 1.05, title, size=11, transform=ax.transAxes)


def axes_frame(ax, origin, angle=0, length=.55, label=None):
    p = np.asarray(origin)
    R = np.array([[np.cos(angle), -np.sin(angle)],
                  [np.sin(angle), np.cos(angle)]])
    ex, ey = R[:, 0], R[:, 1]
    arrow(ax, p, p+length*ex, lw=.8, scale=7)
    arrow(ax, p, p+length*ey, lw=.8, scale=7)
    txt(ax, *(p+(length+.12)*ex), "$x$", size=9)
    txt(ax, *(p+(length+.12)*ey), "$y$", size=9)
    if label:
        txt(ax, p[0]-.15, p[1]-.18, label, size=10)


def robot(ax, center, yaw=0, size=.32, color=INK, ghost=False):
    """Plan view of the repository's circular, four-omni-wheel chassis.

    Wheel centres are on the body +/-X and +/-Y axes (L/R = .245/.300).
    Their rolling directions are tangent to the circle, not four parallel
    tyres and not a corner-mounted mecanum layout.
    """
    p = np.asarray(center)
    R = np.array([[np.cos(yaw), -np.sin(yaw)],
                  [np.sin(yaw), np.cos(yaw)]])
    ls = "--" if ghost else "-"
    ax.add_patch(Circle(p, size, edgecolor=color, facecolor="white",
                        lw=1, ls=ls, zorder=6))
    for theta in (0, np.pi/2, np.pi, 3*np.pi/2):
        radial = np.array([np.cos(theta), np.sin(theta)])
        tangent = np.array([-radial[1], radial[0]])
        c = (.245/.300)*size*radial
        wheel = np.array([c+sr*.065*size*radial+st*(.05/.300)*size*tangent
                          for sr, st in ((-1,-1), (1,-1), (1,1), (-1,1))])
        ax.add_patch(Polygon(wheel@R.T+p, closed=True, fc="white" if ghost else LIGHT,
                             ec=color, lw=.7, ls=ls, zorder=7))
        if not ghost:
            for frac in (-.65, 0, .65):
                mid = c+frac*(.05/.300)*size*tangent
                ends = np.array([mid-.065*size*radial, mid+.065*size*radial])
                line(ax, ends@R.T+p, color=color, lw=.55, zorder=8)
    heading = arrow(ax, p-.50*size*R[:, 0], p-.08*size*R[:, 0],
                    color=color, lw=.8, scale=6)
    heading.set_zorder(9)


def arm(ax, base, tip, color=INK, ghost=False, bend=-.25):
    b, p = np.asarray(base), np.asarray(tip)
    delta = p-b
    n = np.array([-delta[1], delta[0]])
    n /= max(float(np.linalg.norm(n)), 1e-9)
    elbow = b+.48*delta+bend*n
    line(ax, [b, elbow, p], color=color, lw=1.5, ls="--" if ghost else "-", zorder=9)
    joint_radius = min(.045, .045*float(np.linalg.norm(delta)))
    for a in (b, elbow):
        ax.add_patch(Circle(a, joint_radius, ec=color, fc="white", lw=.9, zorder=10))
    ax.plot(*p, marker="o", color=color, ms=3.5, zorder=10)


def export(fig, name, caption, placement):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    w, h = fig.canvas.get_width_height()
    outside = []
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text():
            continue
        bb = t.get_window_extent(renderer)
        if bb.x0 < -1 or bb.y0 < -1 or bb.x1 > w+1 or bb.y1 > h+1:
            outside.append(t.get_text())
    if outside:
        raise RuntimeError(f"{name}: labels outside page: {outside}")
    for ext in ("pdf", "svg", "png"):
        fig.savefig(OUT/f"{name}.{ext}", dpi=300,
                    metadata={"Creator": "Original thesis method schematics; Matplotlib"})
    plt.close(fig)
    MANIFEST.append(dict(file=name, caption=caption, placement=placement,
                         source="本研究自行繪製之概念示意，未使用實驗數據。",
                         chinese_font="DFKai-SB", math_font="STIX",
                         bounds_check="passed"))
    print(f"{name}: PDF/SVG/PNG")


def setpoint_tracking():
    fig = plt.figure(figsize=(7.2, 4.25))
    ax = fig.add_axes([.045, .59, .92, .34])
    panel(ax, "(a) 手臂命令追蹤與全身末端運動學", (0, 11.4), (0, 3.0), equal=False)
    for x, title in ((1.9, "設定點積分"), (5.3, "關節位置追蹤"), (8.7, "末端運動學")):
        ax.add_patch(Rectangle((x-1.1, .95), 2.2, .8, ec=INK, fc="white", lw=1))
        txt(ax, x, 1.35, title, 10.5)
    arrow(ax, (.1, 1.35), (.8, 1.35))
    txt(ax, .3, 1.95, "$u_a$", 12)
    arrow(ax, (3.0, 1.35), (4.2, 1.35))
    txt(ax, 3.6, 1.95, "$s_a$", 12)
    arrow(ax, (6.4, 1.35), (7.6, 1.35))
    txt(ax, 7.0, 1.95, "$q_a$", 12)
    arrow(ax, (8.7, 2.37), (8.7, 1.75))
    txt(ax, 8.7, 2.7, "$ {}^WT_B$", 12)
    arrow(ax, (9.8, 1.35), (10.9, 1.35))
    txt(ax, 10.65, 1.98, "$ {}^WT_E$", 12)
    txt(ax, 1.9, .58, "$s_a^{j+1}=s_a^j+\\Delta t_pu_a^j$", 10)
    txt(ax, 8.7, .58, "$ {}^WT_E={}^WT_B\\,{}^BT_A\\,{}^AT_E(q_a)$", 10)
    txt(ax, 5.7, .02, "增廣狀態同時保留 $q_a$ 與 $s_a$；$u_a$ 為設定點變化率", 9.5)
    ax = fig.add_axes([.12, .14, .81, .29])
    n = np.arange(130)
    s = np.clip((n-12)/50, 0, 1)
    q = np.zeros_like(s)
    for k in range(len(q)-1):
        q[k+1] = q[k]+.10*(s[k]-q[k])
    ax.fill_between(n, q, s, color=LIGHT, zorder=1)
    ax.plot(n, s, "--", color=INK, lw=1.1, label="位置設定點 $s_r^j$")
    ax.plot(n, q, color=INK, lw=1.8, label="實際關節位置 $q_r^j$")
    ax.set(xlim=(0, 130), ylim=(-.06, 1.16), xticks=[], yticks=[])
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    txt(ax, .5, 1.18, "(b) 單軸設定點與實際關節位置", 11, transform=ax.transAxes)
    ax.set_xlabel("物理步索引 $j$", fontproperties=FONT, fontsize=10)
    ax.set_ylabel("關節位置", fontproperties=FONT, fontsize=10)
    ax.legend(loc="lower right", prop=FontProperties(fname=str(FONT_PATH), size=9),
              frameon=False, handlelength=2.2)
    ax.annotate("追蹤差異", xy=(51, .62), xytext=(25, .88),
                fontproperties=FONT, fontsize=9,
                arrowprops=dict(arrowstyle="-", lw=.7), ha="center")
    export(fig, "arm_setpoint_tracking",
           "手臂位置命令、設定點追蹤與末端運動學關係",
           "3.2.2 增廣狀態定義及狀態轉移公式之後")


def dynamic_prediction():
    fig = plt.figure(figsize=(7.2, 3.85))
    axs = [fig.add_axes([.05, .18, .43, .68]), fig.add_axes([.53, .18, .43, .68])]
    ts = np.array([0, 1.5, 3., 4.5])
    obs = [(np.array([2.5, 2.6]), np.array([0, -.8])),
           (np.array([4.2, -1.7]), np.array([-.3, .45]))]
    for i, ax in enumerate(axs):
        panel(ax, ("(a) 障礙運動外推", "(b) 機器人與障礙的同步預測")[i],
              (-1.2, 5.2), (-2.25, 3.25))
        for j, (p, v) in enumerate(obs):
            P = p+ts[:, None]*v
            line(ax, P, color=GRAY, lw=.8, ls=":")
            for k, (pt, tau) in enumerate(zip(P, ts)):
                ax.add_patch(Circle(pt, .23, ec=GRAY, fc="#c8c8c8" if k == 0 else "white",
                                    lw=.9, ls="-" if k == 0 else "--", zorder=2))
            arrow(ax, P[-2], P[-1], color=GRAY, lw=.7, scale=7)
            if i == 0:
                txt(ax, p[0]+.4, p[1]+.15, f"障礙 {j+1}", 9.5, ha="left")
                txt(ax, P[-1, 0]+.4, P[-1, 1], "$t_3$", 10, ha="left")
        robot(ax, (-.8, 0))
        if i == 0:
            arrow(ax, (-.3, 0), (3.5, 0), ls="--", color=INK, lw=1)
            txt(ax, .45, -.6, "原導航走向", 10)
            txt(ax, -.85, -.7, "底盤", 10)
            txt(ax, 2.5, 2.15, "$t_0$", 10)
            txt(ax, 2.05, .3, "$t_2$", 10)
        else:
            tt = np.linspace(0, 4.5, 100)
            styles = [("原前進候選", 1.0, 0., "--", .85),
                      ("減速候選", .48, 0., ":", 1.3),
                      ("側移候選", 1.0, -.95, "-", 1.8)]
            for lab, rho, shift, ls, lw in styles:
                xx = -.8+rho*tt
                yy = np.minimum(tt/2, 1)*shift
                ax.plot(xx, yy, color=INK, ls=ls, lw=lw, zorder=4)
            # Mark the same future instant on all three candidate motions.
            # Speed changes share a geometric path, so distinguish them by
            # their time-indexed position rather than an invented lane offset.
            tau = ts[2]
            for pt, marker, dy in [
                    (np.array([-.8+tau, 0.]), "s", .47),
                    (np.array([-.8+.48*tau, 0.]), "v", .47),
                    (np.array([-.8+tau, -.95]), "o", -.40)]:
                ax.plot(*pt, marker=marker, color=INK, ms=4,
                        mfc="white" if marker != "o" else INK, zorder=9)
                txt(ax, pt[0]-.12, pt[1]+dy, "$t_2$", 9)
            P = obs[0][0]+tau*obs[0][1]
            line(ax, [np.array([-.8+tau, -.95]), P],
                 color="#777777", lw=.8, ls=":")
    handles = [plt.Line2D([], [], color=INK, ls="--", lw=1, marker="s",
                         mfc="white", ms=4, label="原前進候選"),
               plt.Line2D([], [], color=INK, ls=":", lw=1.3, marker="v",
                          mfc="white", ms=4, label="減速候選"),
               plt.Line2D([], [], color=INK, lw=1.8, marker="o",
                          ms=4, label="側移候選")]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .075),
               ncol=3, frameon=False, prop=FontProperties(fname=str(FONT_PATH), size=9))
    fig.text(.5, .025, "以相同未來時刻比較間距；圖中配置與候選運動為概念示意。",
             fontproperties=FONT, fontsize=8.2, ha="center")
    export(fig, "dynamic_obstacle_prediction",
           "動態障礙位置外推與不同速度、側移候選之同步預測示意",
           "3.4.2 最小預測間距定義之後，接續 3.4.3 候選評估")


def visual_reference():
    """One purpose: show how an observed task goal becomes a base target.

    The camera projection was removed: its equations belong to section 3.5.2.
    A and B denote alternative base poses, not extra robots or arm joints.
    This is a labelled illustrative configuration, not an IK/planning result.
    """
    fig = plt.figure(figsize=(7.2, 4.9))
    flow = fig.add_axes([.04, .78, .92, .18])
    flow.set(xlim=(0, 12), ylim=(0, 1.8))
    flow.set_axis_off()
    text_checks = []
    for x, title, detail in (
            (1.85, "1　取得操作目標", "目標位置與家具幾何"),
            (6.0, "2　產生並篩選候選", "淨空、路線、手臂可達性"),
            (10.15, "3　評分並選定位姿", "路線長度與手臂構型")):
        box = Rectangle((x-1.625, .35), 3.25, 1.15,
                        ec=INK, fc="white", lw=1)
        flow.add_patch(box)
        text_checks.extend((box, artist) for artist in (
            txt(flow, x, 1.13, title, 10.2),
            txt(flow, x, .70, detail, 9.1)))
    arrow(flow, (3.475, .925), (4.375, .925), lw=1)
    arrow(flow, (7.625, .925), (8.525, .925), lw=1)

    ax = fig.add_axes([.04, .055, .92, .66])
    ax.set(xlim=(0, 4.8), ylim=(0, 2.9), aspect="equal")
    ax.set_axis_off()
    txt(ax, .68, 2.62, "底盤選位之俯視配置", 10.5)
    # The table/furniture footprint, task goal, and obstacle have direct labels.
    ax.add_patch(Rectangle((1.55, 1.95), 1.95, .75,
                           ec=INK, fc=LIGHT, lw=1.1))
    txt(ax, 2.525, 2.48, "家具俯視範圍", 10.5)
    goal = np.array([2.20, 2.13])
    ax.plot(*goal, marker="o", color=INK, ms=5.5, zorder=10)
    line(ax, [goal+[.08, 0], (2.70, 2.13)], lw=.75)
    txt(ax, 2.76, 2.13, "操作目標", 10.3, ha="left")
    obstacle = Rectangle((3.55, .65), .60, 1.20, ec=INK, fc=LIGHT,
                         hatch="///", lw=1, zorder=2)
    ax.add_patch(obstacle)
    txt(ax, 4.28, 2.03, "障礙物", 10.5)
    line(ax, [(4.22, 1.94), (4.06, 1.81)], lw=.7)

    start = np.array([.60, .62])
    chosen = np.array([2.15, 1.56])
    rejected = np.array([3.45, 1.48])
    radius = .30
    robot(ax, start, yaw=.30, size=radius)
    robot(ax, chosen, yaw=np.pi/2, size=radius)
    ax.add_patch(Circle(rejected, radius, ec=GRAY, fc="none",
                        lw=1.25, ls="--", zorder=8))
    for sign in (-1, 1):
        line(ax, [rejected+[-.10, -sign*.10], rejected+[.10, sign*.10]],
             lw=1.25, zorder=9)
    # B truly intersects the obstacle rectangle in this illustrative geometry;
    # A and the initial pose are outside both fixed footprints.
    def circle_rect_gap(p, rect):
        lo = np.array(rect[:2]); hi = lo+np.array(rect[2:])
        return float(np.linalg.norm(p-np.clip(p, lo, hi))-radius)
    assert circle_rect_gap(rejected, (3.55, .65, .60, 1.20)) < 0
    assert circle_rect_gap(chosen, (3.55, .65, .60, 1.20)) > 0
    assert circle_rect_gap(chosen, (1.55, 1.95, 1.95, .75)) > 0
    arrow(ax, (.91, .63), (1.94, 1.33), rad=-.14, lw=1.5, scale=10)
    txt(ax, 1.34, .47, "導航接近路徑", 10.5)
    txt(ax, .60, .12, "目前底盤位置", 10.5)
    txt(ax, 2.06, .98, "A：選定底盤位姿", 10.5)
    line(ax, [(2.06, 1.10), (2.13, 1.25)], lw=.7)
    txt(ax, 3.57, .14, "B：障礙重疊，排除", 10.5)
    line(ax, [(3.44, .30), (3.23, 1.25)], lw=.7)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for box, artist in text_checks:
        frame = box.get_window_extent(renderer)
        bounds = artist.get_window_extent(renderer)
        if not (frame.x0+1 < bounds.x0 and bounds.x1 < frame.x1-1
                and frame.y0+1 < bounds.y0 and bounds.y1 < frame.y1-1):
            raise RuntimeError("Visual-reference text exceeds box: "+artist.get_text())
    export(fig, "visual_operation_reference",
           "操作目標導引之底盤候選篩選與導航接近",
           "3.5.3 候選底盤位置選擇公式與候選集合說明之後")


def articulated_constraints():
    fig = plt.figure(figsize=(7.2, 5.1))
    axs = [fig.add_axes([.035, .29, .45, .61]),
           fig.add_axes([.54, .29, .43, .61])]
    a, b = axs
    panel(a, "(a) 旋轉門之協同操作", (-.18, 1.52), (-.78, 1.25))
    h = np.array([.15, .20]); phi = np.deg2rad(55)
    R = np.array([[np.cos(phi), -np.sin(phi)], [np.sin(phi), np.cos(phi)]])
    p0 = h+[.78, 0]; p1 = h+R@np.array([.78, 0])
    offset = np.array([0, -.08])
    e0, e1 = p0+offset, p1+R@offset
    # H and E are distinct; the same H-to-E transform is preserved by rotation.
    np.testing.assert_allclose(R.T@(e1-p1), e0-p0, atol=1e-12)
    line(a, [h, h+[.90, 0]], color=GRAY, ls="--", lw=1.2)
    line(a, [h, h+R@np.array([.90, 0])], lw=2.5)
    a.add_patch(Circle(h, .025, ec=INK, fc="white", lw=1, zorder=6))
    a.add_patch(Arc(h, .55, .55, theta1=0, theta2=55, lw=.9))
    arrow(a, h+.275*np.array([np.cos(phi-.15), np.sin(phi-.15)]),
          h+.275*np.array([np.cos(phi), np.sin(phi)]), lw=.8, scale=7)
    txt(a, .51, .36, "$\\phi-\\phi_0$", 11)
    txt(a, .12, .10, "鉸鏈 $h$", 9.5)
    t = np.linspace(0, phi, 60)
    a.plot(h[0]+.78*np.cos(t), h[1]+.78*np.sin(t), ls=":", color=GRAY, lw=.9)
    base0, base1 = np.array([.96, -.25]), np.array([1.02, .62])
    # Keep the displayed yaw unchanged to illustrate that a holonomic base
    # need not align its heading with the translation or with the door angle.
    for base, ee, ghost, color in ((base0, e0, True, GRAY),
                                  (base1, e1, False, INK)):
        robot(a, base, yaw=0, size=.30, ghost=ghost, color=color)
        mount = base+np.array([.11, 0])
        arm(a, mount, ee, ghost=ghost, color=color, bend=.075)
    for pp, ee, color in ((p0, e0, GRAY), (p1, e1, INK)):
        line(a, [pp, ee], color=color, lw=1, ls=":", zorder=9)
        a.plot(*pp, marker="o", ms=4, color=color, mfc="white", zorder=10)
        a.plot(*ee, marker="^", ms=4, color=color, mfc="white", zorder=10)
    txt(a, .49, 1.08, "把手沿鉸鏈圓弧運動", 9.5)
    txt(a, p1[0]-.04, p1[1]+.13, "$H$", 11)
    txt(a, e1[0]+.12, e1[1]-.01, "$E$", 11)
    txt(a, 1.01, -.68, "十字配置四全向輪底盤", 9.3)

    panel(b, "(b) 平移抽屜之軸向操作", (-.20, 1.42), (-.98, 1.30))
    b.add_patch(Rectangle((.12, .30), .98, .88, ec=INK, fc=LIGHT, lw=1))
    txt(b, .61, 1.06, "櫃體", 10)
    b.add_patch(Rectangle((.17, -.12), .88, .87, ec=INK, fc="white", lw=1.1))
    line(b, [(.17, .30), (1.05, .30)], ls="--", color=GRAY, lw=.9)
    line(b, [(.42, .30), (.80, .30)], ls="--", color=GRAY, lw=2)
    line(b, [(.42, -.12), (.80, -.12)], lw=2.5)
    arrow(b, (-.035, .28), (-.035, -.16), lw=1)
    txt(b, -.10, .08, "$a_d$", 11)
    txt(b, 1.30, .10, "$d$", 12)
    line(b, [(1.12, .30), (1.29, .30)], color=GRAY, lw=.7)
    line(b, [(1.12, -.12), (1.29, -.12)], color=GRAY, lw=.7)
    b.add_patch(FancyArrowPatch((1.23, .30), (1.23, -.12),
                              arrowstyle="<->", mutation_scale=8, lw=.8, color=INK))
    drawer_base = np.array([.61, -.64])
    hd, ed = np.array([.61, -.12]), np.array([.61, -.20])
    robot(b, drawer_base, yaw=np.pi/2, size=.30)
    arm(b, drawer_base+[0, .11], ed, bend=-.08)
    line(b, [hd, ed], lw=1, ls=":", zorder=9)
    b.plot(*hd, marker="o", ms=4, color=INK, mfc="white", zorder=10)
    b.plot(*ed, marker="^", ms=4, color=INK, mfc="white", zorder=10)
    txt(b, .78, -.08, "$H$", 11)
    txt(b, .78, -.24, "$E$", 11)
    txt(b, .61, .87, "$p_H(d)=p_{H,0}+d\\,a_d$", 10)
    txt(b, .61, .58, "$R_H(d)=R_{H,0}$", 10)

    inset = fig.add_axes([.045, .025, .44, .19])
    inset.set(xlim=(-.45, 1.35), ylim=(-.5, .62), aspect="equal")
    inset.set_axis_off()
    robot(inset, (0, 0), size=.24)
    arrow(inset, (.29, 0), (.80, 0), lw=.9, scale=7)
    arrow(inset, (0, .29), (0, .56), lw=.9, scale=7)
    txt(inset, .94, 0, "$v_x^B$", 11)
    txt(inset, .16, .53, "$v_y^B$", 11)
    inset.add_patch(Arc((0, 0), .70, .70, theta1=195, theta2=325, lw=.9))
    angle = np.deg2rad(325)
    arrow(inset, .35*np.array([np.cos(angle-.15), np.sin(angle-.15)]),
          .35*np.array([np.cos(angle), np.sin(angle)]), lw=.9, scale=7)
    txt(inset, .55, -.31, "$\\omega_B$", 11)
    fig.text(.72, .19, "抓持後之固定相對位姿", fontproperties=FONT,
             fontsize=10, ha="center")
    fig.text(.72, .135, "$ {}^WT_E={}^WT_H(\\eta)\\,{}^HT_E$",
             fontproperties=FONT, fontsize=11, ha="center")
    fig.text(.72, .08, "○ 把手 $H$　△ 末端 $E$", fontproperties=FONT,
             fontsize=9.5, ha="center")
    fig.text(.50, .252, "虛線：初始構型；實線：操作中構型。",
             fontproperties=FONT, fontsize=9, ha="center")
    export(fig, "articulated_operation_constraints",
           "旋轉門與平移抽屜之機構運動及移動機械臂協同操作示意",
           "3.6.2 旋轉門與平移抽屜的機構模型公式之後")


def execution_timeline():
    fig = plt.figure(figsize=(7.2, 3.7))
    ax = fig.add_axes([.04, .10, .93, .83])
    panel(ax, "", (0, 11), (0, 5.6), equal=False)
    t0, te = 2.05, 6.0
    for x in (t0, te):
        line(ax, [(x, .55), (x, 5.35)], ls=":", color=GRAY, lw=.8)
    txt(ax, t0, 5.48, "$t_k$", 12)
    txt(ax, te, 5.48, "$t_k^{\\mathrm{eff}}$", 12)
    arrow(ax, (t0, 5.0), (te, 5.0), lw=1)
    txt(ax, 4.0, 5.25, "在途命令前推 $D_k\\Delta t_p$", 10)
    txt(ax, 1.42, 4.32, "狀態", 10, ha="right")
    txt(ax, t0+.13, 4.32, "$z_k^{\\mathrm{ex}}$", 11, ha="left")
    arrow(ax, (3.15, 4.32), (5.35, 4.32), ls="--", lw=.9)
    txt(ax, te+.15, 4.32, "生效起點 $\\zeta_{0|k}$", 10, ha="left")
    txt(ax, 1.42, 3.2, "候選計算", 10, ha="right")
    ax.add_patch(Rectangle((t0, 2.86), 2.95, .64, ec=INK, fc=LIGHT, lw=.9))
    txt(ax, 3.52, 3.18, "狀態預測、QP 與可行性核對", 9.4)
    arrow(ax, (5.03, 3.18), (5.62, 3.18), lw=.9)
    txt(ax, 5.55, 3.83, "結果到達", 9)
    txt(ax, te+.2, 3.18, "生效前完成接受判定", 9.5, ha="left")
    txt(ax, 1.42, 2.04, "通過時執行", 10, ha="right")
    for k in range(4):
        x = t0+k*(te-t0)/4
        ax.add_patch(Rectangle((x, 1.69), (te-t0)/4, .65,
                               ec=INK, fc="#dddddd", lw=.7))
        txt(ax, x+(te-t0)/8, 2.02, "$v_"+str(k)+"$", 10)
    ax.add_patch(Rectangle((te, 1.69), 2.4, .65, ec=INK, fc="white", lw=1.2))
    txt(ax, te+1.2, 2.02, "新控制段", 10)
    arrow(ax, (8.5, 2.02), (10.4, 2.02), lw=.9)
    txt(ax, 9.45, 2.42, "後續控制週期", 9.3)
    txt(ax, 1.42, .88, "未通過時執行", 10, ha="right")
    line(ax, [(t0, .88), (te, .88)], color=GRAY, lw=1.2)
    ax.add_patch(Rectangle((te, .55), 3.75, .65, ec=INK, fc="white",
                           hatch="///", lw=.8))
    txt(ax, te+1.88, .88, "已核對的停止尾段", 9.7,
        bbox=dict(facecolor="white", edgecolor="none", pad=2))
    txt(ax, 4.0, 1.42, "已排定命令持續作用", 9.2)
    fig.text(.5, .035, "邏輯時序示意；各區段長度不代表實測耗時。",
             fontproperties=FONT, fontsize=8.2, ha="center")
    export(fig, "command_execution_timeline",
           "在途命令前推、新控制段接受與停止備援之執行時序示意",
           "3.7.1 延遲補償初始狀態公式之後")


def overall_workflow():
    fig = plt.figure(figsize=(7.2, 4.0))
    ax = fig.add_axes([.025, .02, .95, .96])
    ax.set(xlim=(0, 12), ylim=(0, 6.8))
    ax.set_axis_off()
    def box(x, y, title, detail):
        ax.add_patch(Rectangle((x-1.53, y-.82), 3.06, 1.64,
                               ec=INK, fc="white", lw=1))
        txt(ax, x, y+.34, title, 10.4)
        line(ax, [(x-1.36, y+.04), (x+1.36, y+.04)], lw=.5, color=GRAY)
        txt(ax, x, y-.35, detail, 9.1)
    box(2, 5.15, "1　狀態與有效觀測", "位姿、關節與設定點\n雷射、視覺及時間資訊")
    box(6, 5.15, "2　命令執行狀態前推", "偏置估測與在途命令\n建立生效起點狀態")
    box(10, 5.15, "3　任務與導航參考", "目標、操作進度與機構\n障礙預測及候選評估")
    box(10, 2.5, "4　全身 QP 求解", "底盤與末端追蹤\nCBF、命令與機構限制")
    box(6, 2.5, "5　候選控制段核對", "求解、淨空與停止尾段\n版本、期限及階段交接")
    box(2, 2.5, "6　放行、執行與回授", "提交合格命令\n回報最終輸入與新狀態")
    for a, b in [((3.53, 5.15), (4.47, 5.15)),
                 ((7.53, 5.15), (8.47, 5.15)),
                 ((10, 4.33), (10, 3.32)),
                 ((8.47, 2.5), (7.53, 2.5)),
                 ((4.47, 2.5), (3.53, 2.5))]:
        arrow(ax, a, b, lw=1)
    txt(ax, 4.0, 2.88, "通過", 8.8)
    polyarrow(ax, [(.47, 2.5), (.15, 2.5), (.15, 6.36),
                   (2, 6.36), (2, 5.97)], lw=.9, ls="--")
    ax.add_patch(Rectangle((3.3, .32), 5.4, .68,
                           ec=GRAY, fc=LIGHT, lw=.8))
    txt(ax, 6, .66, "逾時或不合格：沿已核對停止尾段執行", 9.3)
    arrow(ax, (6, 1.68), (6, 1.0), lw=.9, ls="--")
    polyarrow(ax, [(3.3, .66), (2, .66), (2, 1.68)], lw=.9, ls="--")
    txt(ax, 6, 6.43, "觀測、預測、求解與執行之閉迴路", 11)
    export(fig, "wholebody_control_workflow",
           "全身預測控制之觀測更新、參考生成、求解與命令放行流程",
           "3.7.4 第一段之後、演算法步驟之前")


def contact_sheet():
    fig, axes = plt.subplots(3, 2, figsize=(12, 10.2))
    fig.subplots_adjust(left=.025, right=.975, top=.945, bottom=.02,
                        wspace=.07, hspace=.12)
    for ax, item in zip(axes.flat, MANIFEST):
        ax.imshow(plt.imread(OUT/f"{item['file']}.png"))
        ax.set_axis_off()
        ax.set_title(item["placement"].split(" ")[0], fontproperties=FONT, fontsize=16, pad=8)
    fig.savefig(OUT/"chapter3_figures_overview.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    setpoint_tracking()
    dynamic_prediction()
    visual_reference()
    articulated_constraints()
    execution_timeline()
    overall_workflow()
    contact_sheet()
    (OUT/"figure_manifest.json").write_text(
        json.dumps(MANIFEST, ensure_ascii=False, indent=2)+"\n")
